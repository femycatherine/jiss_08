(function ($) {

    'use strict';

    jQuery(document).ready(function () {		

			$(window).on("scroll", function () {

				if ($(this).scrollTop() > 250) {

					$('.gotop').fadeIn();

				} else {

					$('.gotop').fadeOut();

				}

			});

			